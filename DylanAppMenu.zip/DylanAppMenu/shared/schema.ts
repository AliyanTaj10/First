import { z } from "zod";

export const menuItemSchema = z.object({
  id: z.string(),
  name: z.string(),
  price: z.number(),
  description: z.string(),
  image: z.string(),
  category: z.enum(['food', 'drinks']),
  preparationTime: z.string().optional(),
  tags: z.array(z.string()).optional(),
});

export const cartItemSchema = menuItemSchema.extend({
  quantity: z.number().min(1),
});

export const orderSchema = z.object({
  id: z.string(),
  tableNumber: z.number(),
  items: z.array(cartItemSchema),
  foodItems: z.array(cartItemSchema),
  drinkItems: z.array(cartItemSchema),
  total: z.number(),
  timestamp: z.string(),
  status: z.enum(['pending', 'confirmed', 'preparing', 'ready', 'delivered']),
});

export const insertOrderSchema = orderSchema.omit({ id: true, timestamp: true });

export type MenuItem = z.infer<typeof menuItemSchema>;
export type CartItem = z.infer<typeof cartItemSchema>;
export type Order = z.infer<typeof orderSchema>;
export type InsertOrder = z.infer<typeof insertOrderSchema>;
