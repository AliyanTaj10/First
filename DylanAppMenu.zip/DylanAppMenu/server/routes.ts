import type { Express } from "express";
import { createServer, type Server } from "http";

export async function registerRoutes(app: Express): Promise<Server> {
  // This application runs entirely offline with local data
  // No API routes needed as everything is handled client-side
  
  // Health check endpoint for monitoring
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", message: "Dylan Patisserie Menu App" });
  });

  const httpServer = createServer(app);
  return httpServer;
}
