import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { ShoppingCart } from "lucide-react";
import { useCartStore } from "@/lib/cart-store";
import { getItemsByCategory } from "@/lib/menu-data";
import MenuItemCard from "@/components/menu-item-card";
import ItemDetailModal from "@/components/item-detail-modal";
import dylanLogoPath from "@assets/image_1753796115842.png";
import { MenuItem } from "@shared/schema";

export default function Menu() {
  const [, setLocation] = useLocation();
  const [category, setCategory] = useState<'all' | 'food' | 'drinks'>('all');
  const [selectedItem, setSelectedItem] = useState<MenuItem | null>(null);
  
  const { tableNumber, getItemCount } = useCartStore();
  const items = getItemsByCategory(category);
  const cartCount = getItemCount();

  const handleCategoryChange = (newCategory: 'all' | 'food' | 'drinks') => {
    setCategory(newCategory);
  };

  const handleItemClick = (item: MenuItem) => {
    setSelectedItem(item);
  };

  const handleCloseModal = () => {
    setSelectedItem(null);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white luxury-shadow border-b luxury-border sticky top-0 z-40">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <img 
                src={dylanLogoPath} 
                alt="Dylan Signature" 
                className="h-12 object-contain"
              />
              <div>
                <h1 className="font-playfair text-2xl font-bold text-dylan-black">
                  Dylan Patisserie
                </h1>
                <p className="text-sm text-dylan-brown">
                  Table {tableNumber}
                </p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              {/* Category Navigation */}
              <nav className="flex space-x-2">
                <Button
                  variant={category === 'all' ? 'default' : 'outline'}
                  onClick={() => handleCategoryChange('all')}
                  className={`px-6 py-2 rounded-full font-medium transition-all ${
                    category === 'all' 
                      ? 'bg-dylan-gold text-white hover:bg-dylan-gold/90' 
                      : 'bg-dylan-beige text-dylan-brown hover:bg-dylan-gold hover:text-white border-dylan-gold/30'
                  }`}
                >
                  All Items
                </Button>
                <Button
                  variant={category === 'food' ? 'default' : 'outline'}
                  onClick={() => handleCategoryChange('food')}
                  className={`px-6 py-2 rounded-full font-medium transition-all ${
                    category === 'food' 
                      ? 'bg-dylan-gold text-white hover:bg-dylan-gold/90' 
                      : 'bg-dylan-beige text-dylan-brown hover:bg-dylan-gold hover:text-white border-dylan-gold/30'
                  }`}
                >
                  Food
                </Button>
                <Button
                  variant={category === 'drinks' ? 'default' : 'outline'}
                  onClick={() => handleCategoryChange('drinks')}
                  className={`px-6 py-2 rounded-full font-medium transition-all ${
                    category === 'drinks' 
                      ? 'bg-dylan-gold text-white hover:bg-dylan-gold/90' 
                      : 'bg-dylan-beige text-dylan-brown hover:bg-dylan-gold hover:text-white border-dylan-gold/30'
                  }`}
                >
                  Drinks
                </Button>
              </nav>
              
              {/* Cart Button */}
              <Button
                onClick={() => setLocation("/cart")}
                className="bg-dylan-gold hover:bg-dylan-gold/90 text-white px-6 py-2 rounded-full font-semibold transition-all relative luxury-shadow"
              >
                <ShoppingCart className="mr-2 h-5 w-5" />
                Cart
                {cartCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-6 w-6 flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Menu Items Grid */}
      <main className="container mx-auto px-6 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {items.map((item) => (
            <MenuItemCard
              key={item.id}
              item={item}
              onClick={() => handleItemClick(item)}
            />
          ))}
        </div>
      </main>

      {/* Item Detail Modal */}
      {selectedItem && (
        <ItemDetailModal
          item={selectedItem}
          isOpen={!!selectedItem}
          onClose={handleCloseModal}
        />
      )}
    </div>
  );
}
