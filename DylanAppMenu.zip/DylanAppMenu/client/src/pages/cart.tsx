import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft } from "lucide-react";
import { useCartStore } from "@/lib/cart-store";
import { getRecommendations } from "@/lib/recommendations";
import CartItem from "@/components/cart-item";
import RecommendationItem from "@/components/recommendation-item";
import dylanLogoPath from "@assets/image_1753796115842.png";

export default function Cart() {
  const [, setLocation] = useLocation();
  const { 
    items, 
    tableNumber, 
    getTotal, 
    getFoodItems, 
    getDrinkItems 
  } = useCartStore();
  
  const total = getTotal();
  const recommendations = getRecommendations(items);
  const foodItems = getFoodItems();
  const drinkItems = getDrinkItems();

  const handlePlaceOrder = () => {
    if (items.length === 0) return;
    
    // In a real app, this would send orders to different printers
    console.log('Food items for kitchen:', foodItems);
    console.log('Drink items for bar:', drinkItems);
    
    setLocation("/confirmation");
  };

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50">
        <header className="bg-white luxury-shadow border-b luxury-border">
          <div className="container mx-auto px-6 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Button
                  variant="ghost"
                  onClick={() => setLocation("/menu")}
                  className="text-dylan-gold hover:text-dylan-gold/80 transition-colors p-2"
                >
                  <ArrowLeft className="h-6 w-6" />
                </Button>
                <div>
                  <h1 className="font-playfair text-2xl font-bold text-dylan-black">
                    Your Order
                  </h1>
                  <p className="text-sm text-dylan-brown">Table {tableNumber}</p>
                </div>
              </div>
              <img 
                src={dylanLogoPath} 
                alt="Dylan Signature" 
                className="h-12 object-contain"
              />
            </div>
          </div>
        </header>

        <div className="container mx-auto px-6 py-16 text-center">
          <Card className="max-w-md mx-auto luxury-shadow luxury-border">
            <CardContent className="pt-12 pb-12">
              <div className="text-6xl mb-4">🛒</div>
              <h2 className="font-playfair text-2xl font-bold text-dylan-black mb-4">
                Your cart is empty
              </h2>
              <p className="text-dylan-brown mb-6">
                Add some delicious items from our menu
              </p>
              <Button
                onClick={() => setLocation("/menu")}
                className="bg-dylan-gold hover:bg-dylan-gold/90 text-white font-semibold py-3 px-6 rounded-xl transition-all"
              >
                Browse Menu
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white luxury-shadow border-b luxury-border">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                onClick={() => setLocation("/menu")}
                className="text-dylan-gold hover:text-dylan-gold/80 transition-colors p-2"
              >
                <ArrowLeft className="h-6 w-6" />
              </Button>
              <div>
                <h1 className="font-playfair text-2xl font-bold text-dylan-black">
                  Your Order
                </h1>
                <p className="text-sm text-dylan-brown">Table {tableNumber}</p>
              </div>
            </div>
            <img 
              src={dylanLogoPath} 
              alt="Dylan Signature" 
              className="h-12 object-contain"
            />
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2">
            <Card className="luxury-shadow luxury-border">
              <CardContent className="p-6">
                <h2 className="font-playfair text-xl font-bold text-dylan-black mb-6">
                  Order Items
                </h2>
                
                <div className="space-y-4">
                  {items.map((item) => (
                    <CartItem key={item.id} item={item} />
                  ))}
                </div>

                <div className="mt-6 pt-6 border-t luxury-border">
                  <div className="flex justify-between items-center text-xl font-bold">
                    <span className="text-dylan-black">Total:</span>
                    <span className="text-dylan-gold font-playfair">
                      ${total.toFixed(2)}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recommendations & Order Actions */}
          <div className="space-y-6">
            {/* Recommendations */}
            {recommendations.length > 0 && (
              <Card className="luxury-shadow luxury-border">
                <CardContent className="p-6">
                  <h2 className="font-playfair text-xl font-bold text-dylan-black mb-4">
                    Recommended
                  </h2>
                  <div className="space-y-4">
                    {recommendations.map((item) => (
                      <RecommendationItem key={item.id} item={item} />
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Order Actions */}
            <Card className="luxury-shadow luxury-border">
              <CardContent className="p-6">
                <div className="space-y-4">
                  <Button
                    onClick={handlePlaceOrder}
                    className="w-full bg-dylan-gold hover:bg-dylan-gold/90 text-white font-semibold py-4 px-6 rounded-xl transition-all duration-200 transform hover:scale-105 luxury-shadow"
                  >
                    <span className="mr-2">✓</span>
                    Place Order
                  </Button>
                  
                  <Button
                    onClick={() => setLocation("/menu")}
                    variant="outline"
                    className="w-full bg-gray-200 hover:bg-gray-300 text-dylan-black font-semibold py-3 px-6 rounded-xl transition-all border-gray-300"
                  >
                    <ArrowLeft className="mr-2 h-4 w-4" />
                    Continue Shopping
                  </Button>
                </div>
                
                <div className="mt-4 pt-4 border-t luxury-border">
                  <div className="text-xs text-dylan-brown space-y-1">
                    <div className="flex justify-between items-center">
                      <span>Food items → Kitchen</span>
                      <span className="text-dylan-gold">🍽️</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Drinks → Bar</span>
                      <span className="text-dylan-gold">🍸</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
