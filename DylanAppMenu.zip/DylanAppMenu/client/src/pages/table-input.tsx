import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight } from "lucide-react";
import { useCartStore } from "@/lib/cart-store";
import dylanLogoPath from "@assets/image_1753796115842.png";

export default function TableInput() {
  const [tableNumber, setTableNumber] = useState("");
  const [, setLocation] = useLocation();
  const setTableNumberInStore = useCartStore(state => state.setTableNumber);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const num = parseInt(tableNumber);
    if (num && num > 0 && num <= 50) {
      setTableNumberInStore(num);
      setLocation("/menu");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-dylan-beige to-white px-8">
      <Card className="w-full max-w-md luxury-shadow luxury-border">
        <CardContent className="pt-12 pb-12 px-12">
          <div className="text-center mb-8">
            <img 
              src={dylanLogoPath} 
              alt="Dylan Signature" 
              className="h-16 mx-auto mb-6 object-contain"
            />
            <h1 className="font-playfair text-3xl font-bold text-dylan-black mb-2">
              Welcome
            </h1>
            <p className="text-dylan-brown font-medium">
              Please enter the table number
            </p>
          </div>
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <Label 
                htmlFor="table-number" 
                className="block text-sm font-semibold text-dylan-black mb-2"
              >
                Table Number
              </Label>
              <Input
                id="table-number"
                type="number"
                value={tableNumber}
                onChange={(e) => setTableNumber(e.target.value)}
                className="w-full px-4 py-4 text-2xl text-center border-2 focus:border-dylan-gold bg-dylan-beige/20 luxury-border"
                placeholder="Enter table number"
                min="1"
                max="50"
                required
              />
            </div>
            
            <Button 
              type="submit"
              className="w-full bg-dylan-gold hover:bg-dylan-gold/90 text-white font-semibold py-4 px-6 rounded-xl transition-all duration-200 transform hover:scale-105 luxury-shadow"
              disabled={!tableNumber || parseInt(tableNumber) <= 0}
            >
              <ArrowRight className="mr-2 h-5 w-5" />
              Start Order
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
