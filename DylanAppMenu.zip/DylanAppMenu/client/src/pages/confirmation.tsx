import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Plus, Table } from "lucide-react";
import { useCartStore } from "@/lib/cart-store";

export default function Confirmation() {
  const [, setLocation] = useLocation();
  const { tableNumber, clearCart } = useCartStore();
  
  const orderNumber = Math.floor(Math.random() * 100000);

  const handleNewOrder = () => {
    clearCart();
    setLocation("/menu");
  };

  const handleChangeTable = () => {
    clearCart();
    setLocation("/");
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-dylan-beige to-white px-8">
      <Card className="w-full max-w-lg luxury-shadow luxury-border">
        <CardContent className="pt-12 pb-12 px-12 text-center">
          <div className="mb-8">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-3xl text-green-600">✓</span>
            </div>
            <h1 className="font-playfair text-3xl font-bold text-dylan-black mb-2">
              Order Confirmed!
            </h1>
            <p className="text-dylan-brown">
              Your order has been sent to the kitchen and bar
            </p>
          </div>
          
          <div className="bg-dylan-beige/30 rounded-2xl p-6 mb-8 luxury-border">
            <div className="text-sm text-dylan-brown mb-2">Order for</div>
            <div className="font-playfair text-2xl font-bold text-dylan-black mb-4">
              Table {tableNumber}
            </div>
            <div className="text-sm text-dylan-brown">
              Order #{orderNumber.toString().padStart(5, '0')}
            </div>
          </div>
          
          <div className="space-y-4">
            <Button
              onClick={handleNewOrder}
              className="w-full bg-dylan-gold hover:bg-dylan-gold/90 text-white font-semibold py-4 px-6 rounded-xl transition-all duration-200 transform hover:scale-105 luxury-shadow"
            >
              <Plus className="mr-2 h-5 w-5" />
              Start New Order
            </Button>
            
            <Button
              onClick={handleChangeTable}
              variant="outline"
              className="w-full bg-gray-200 hover:bg-gray-300 text-dylan-black font-semibold py-3 px-6 rounded-xl transition-all border-gray-300"
            >
              <Table className="mr-2 h-5 w-5" />
              Change Table
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
