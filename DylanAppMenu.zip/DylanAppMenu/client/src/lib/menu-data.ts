import { MenuItem } from "@shared/schema";

export const menuData: { food: MenuItem[]; drinks: MenuItem[] } = {
  food: [
    {
      id: 'cheesecake',
      name: 'Strawberry Cheesecake',
      price: 24.00,
      description: 'Rich cream cheese with fresh strawberries and graham cracker crust. Made with premium Philadelphia cream cheese and fresh local strawberries.',
      image: 'https://images.unsplash.com/photo-1565958011703-44f9829ba187?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600',
      category: 'food' as const,
      preparationTime: '10-15 minutes',
      tags: ['dessert', 'cream cheese', 'strawberry', 'premium']
    },
    {
      id: 'croissant',
      name: 'Butter Croissant',
      price: 8.00,
      description: 'Flaky, buttery pastry made with premium French butter. Hand-laminated with 84 layers for perfect texture.',
      image: 'https://images.unsplash.com/photo-1555507036-ab794f6eb3bf?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600',
      category: 'food' as const,
      preparationTime: '5-8 minutes',
      tags: ['pastry', 'butter', 'french', 'breakfast']
    },
    {
      id: 'macaron',
      name: 'French Macarons',
      price: 18.00,
      description: 'Delicate almond cookies with ganache filling - box of 6. Available in vanilla, chocolate, raspberry, and pistachio.',
      image: 'https://images.unsplash.com/photo-1558312657-b2dead03d494?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600',
      category: 'food' as const,
      preparationTime: '3-5 minutes',
      tags: ['macaron', 'almond', 'ganache', 'assorted']
    },
    {
      id: 'tiramisu',
      name: 'Classic Tiramisu',
      price: 16.00,
      description: 'Coffee-soaked ladyfingers with mascarpone and cocoa dust. Made with authentic Italian mascarpone and strong espresso.',
      image: 'https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600',
      category: 'food' as const,
      preparationTime: '8-12 minutes',
      tags: ['dessert', 'coffee', 'mascarpone', 'italian']
    },
    {
      id: 'chocolate-tart',
      name: 'Dark Chocolate Tart',
      price: 22.00,
      description: 'Rich dark chocolate ganache in crisp pastry shell. Made with 70% Belgian chocolate and gold leaf garnish.',
      image: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600',
      category: 'food' as const,
      preparationTime: '12-15 minutes',
      tags: ['chocolate', 'tart', 'belgian', 'luxury']
    },
    {
      id: 'quiche',
      name: 'Salmon & Dill Quiche',
      price: 19.00,
      description: 'Flaky pastry filled with smoked salmon, fresh dill, and creamy custard. Served warm with seasonal greens.',
      image: 'https://images.unsplash.com/photo-1612378394997-d46059142ba8?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600',
      category: 'food' as const,
      preparationTime: '15-20 minutes',
      tags: ['savory', 'salmon', 'dill', 'custard']
    },
    {
      id: 'opera-cake',
      name: 'Opera Cake',
      price: 26.00,
      description: 'Layers of almond sponge, chocolate ganache, and coffee buttercream. Glazed with chocolate mirror finish.',
      image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600',
      category: 'food' as const,
      preparationTime: '10-15 minutes',
      tags: ['opera', 'almond', 'chocolate', 'coffee']
    },
    {
      id: 'eclair',
      name: 'Vanilla Éclair',
      price: 12.00,
      description: 'Choux pastry filled with vanilla pastry cream and topped with chocolate fondant. Classic French patisserie.',
      image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600',
      category: 'food' as const,
      preparationTime: '5-8 minutes',
      tags: ['eclair', 'vanilla', 'choux', 'cream']
    }
  ],
  drinks: [
    {
      id: 'cappuccino',
      name: 'Cappuccino',
      price: 6.50,
      description: 'Rich espresso with steamed milk and artistic foam. Made with our signature blend of Ethiopian and Colombian beans.',
      image: 'https://images.unsplash.com/photo-1572442388796-11668a67e53d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600',
      category: 'drinks' as const,
      preparationTime: '3-5 minutes',
      tags: ['coffee', 'espresso', 'milk', 'foam']
    },
    {
      id: 'wine',
      name: 'House Red Wine',
      price: 12.00,
      description: 'Full-bodied red wine with notes of dark fruit and spice. Château de Dylan reserve from Bordeaux region.',
      image: 'https://images.unsplash.com/photo-1474722883778-792e7990302f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600',
      category: 'drinks' as const,
      preparationTime: 'Served immediately',
      tags: ['wine', 'red', 'bordeaux', 'full-bodied']
    },
    {
      id: 'cocktail',
      name: 'Signature Cocktail',
      price: 15.00,
      description: 'House specialty with premium spirits and fresh ingredients. Gold-infused gin with elderflower and citrus.',
      image: 'https://images.unsplash.com/photo-1546171753-97d7676e4602?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600',
      category: 'drinks' as const,
      preparationTime: '5-8 minutes',
      tags: ['cocktail', 'gin', 'elderflower', 'premium']
    },
    {
      id: 'tea',
      name: 'Earl Grey Tea',
      price: 5.50,
      description: 'Premium loose leaf tea with bergamot and lavender. Served with honey and lemon on the side.',
      image: 'https://images.unsplash.com/photo-1544787219-7f47ccb76574?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600',
      category: 'drinks' as const,
      preparationTime: '3-5 minutes',
      tags: ['tea', 'earl grey', 'bergamot', 'lavender']
    },
    {
      id: 'latte',
      name: 'Vanilla Latte',
      price: 7.00,
      description: 'Smooth espresso with steamed milk and Madagascar vanilla syrup. Topped with artistic latte art.',
      image: 'https://images.unsplash.com/photo-1485808191679-5f86510681a2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600',
      category: 'drinks' as const,
      preparationTime: '4-6 minutes',
      tags: ['coffee', 'latte', 'vanilla', 'milk']
    },
    {
      id: 'champagne',
      name: 'Dom Pérignon',
      price: 35.00,
      description: 'Prestigious champagne with fine bubbles and complex flavors. Perfect for celebrations and special occasions.',
      image: 'https://images.unsplash.com/photo-1549297161-6e4fb191e388?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600',
      category: 'drinks' as const,
      preparationTime: 'Served immediately',
      tags: ['champagne', 'luxury', 'bubbles', 'celebration']
    }
  ]
};

export const getAllItems = (): MenuItem[] => {
  return [...menuData.food, ...menuData.drinks];
};

export const getItemById = (id: string): MenuItem | undefined => {
  return getAllItems().find(item => item.id === id);
};

export const getItemsByCategory = (category: 'food' | 'drinks' | 'all'): MenuItem[] => {
  if (category === 'all') return getAllItems();
  return menuData[category];
};
