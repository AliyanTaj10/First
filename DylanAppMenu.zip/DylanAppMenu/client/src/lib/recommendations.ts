import { CartItem, MenuItem } from "@shared/schema";
import { menuData } from "./menu-data";

export interface RecommendationRule {
  if: (cartItems: CartItem[]) => boolean;
  recommend: string[];
}

const recommendationRules: RecommendationRule[] = [
  // Coffee with desserts
  {
    if: (items) => items.some(item => 
      item.category === 'food' && 
      (item.tags?.includes('dessert') || item.tags?.includes('chocolate'))
    ),
    recommend: ['cappuccino', 'latte']
  },
  
  // Tea with light pastries
  {
    if: (items) => items.some(item => 
      item.category === 'food' && 
      (item.tags?.includes('pastry') || item.tags?.includes('macaron'))
    ),
    recommend: ['tea']
  },
  
  // Wine with savory items
  {
    if: (items) => items.some(item => 
      item.category === 'food' && 
      item.tags?.includes('savory')
    ),
    recommend: ['wine', 'champagne']
  },
  
  // Champagne with luxury items
  {
    if: (items) => items.some(item => 
      item.tags?.includes('luxury') || item.tags?.includes('opera')
    ),
    recommend: ['champagne']
  },
  
  // More desserts if already ordering sweets
  {
    if: (items) => items.some(item => 
      item.category === 'food' && 
      item.tags?.includes('dessert')
    ),
    recommend: ['macaron', 'eclair', 'chocolate-tart']
  },
  
  // Cocktails with special occasions
  {
    if: (items) => items.some(item => 
      item.price > 20
    ),
    recommend: ['cocktail', 'champagne']
  }
];

export const getRecommendations = (cartItems: CartItem[]): MenuItem[] => {
  const cartItemIds = cartItems.map(item => item.id);
  const allItems = [...menuData.food, ...menuData.drinks];
  const recommendedIds = new Set<string>();

  // Apply recommendation rules
  recommendationRules.forEach(rule => {
    if (rule.if(cartItems)) {
      rule.recommend.forEach(id => {
        if (!cartItemIds.includes(id)) {
          recommendedIds.add(id);
        }
      });
    }
  });

  // Convert IDs to items and limit to 4 recommendations
  const recommendations = Array.from(recommendedIds)
    .map(id => allItems.find(item => item.id === id))
    .filter(Boolean)
    .slice(0, 4) as MenuItem[];

  // If no specific recommendations, suggest popular items not in cart
  if (recommendations.length === 0) {
    const popularItems = ['cappuccino', 'macaron', 'wine', 'croissant'];
    return popularItems
      .filter(id => !cartItemIds.includes(id))
      .map(id => allItems.find(item => item.id === id))
      .filter(Boolean)
      .slice(0, 2) as MenuItem[];
  }

  return recommendations;
};
