import { CartItem } from "@shared/schema";
import { create } from "zustand";

interface CartStore {
  items: CartItem[];
  tableNumber: number | null;
  addItem: (item: CartItem) => void;
  removeItem: (id: string) => void;
  updateQuantity: (id: string, quantity: number) => void;
  clearCart: () => void;
  setTableNumber: (tableNumber: number) => void;
  getTotal: () => number;
  getFoodItems: () => CartItem[];
  getDrinkItems: () => CartItem[];
  getItemCount: () => number;
}

export const useCartStore = create<CartStore>((set, get) => ({
  items: [],
  tableNumber: null,

  addItem: (newItem: CartItem) => set((state) => {
    const existingItemIndex = state.items.findIndex(item => item.id === newItem.id);
    
    if (existingItemIndex > -1) {
      const updatedItems = [...state.items];
      updatedItems[existingItemIndex].quantity += newItem.quantity;
      return { items: updatedItems };
    } else {
      return { items: [...state.items, newItem] };
    }
  }),

  removeItem: (id: string) => set((state) => ({
    items: state.items.filter(item => item.id !== id)
  })),

  updateQuantity: (id: string, quantity: number) => set((state) => {
    if (quantity <= 0) {
      return { items: state.items.filter(item => item.id !== id) };
    }
    
    const updatedItems = state.items.map(item =>
      item.id === id ? { ...item, quantity } : item
    );
    return { items: updatedItems };
  }),

  clearCart: () => set({ items: [] }),

  setTableNumber: (tableNumber: number) => set({ tableNumber }),

  getTotal: () => {
    const { items } = get();
    return items.reduce((total, item) => total + (item.price * item.quantity), 0);
  },

  getFoodItems: () => {
    const { items } = get();
    return items.filter(item => item.category === 'food');
  },

  getDrinkItems: () => {
    const { items } = get();
    return items.filter(item => item.category === 'drinks');
  },

  getItemCount: () => {
    const { items } = get();
    return items.reduce((count, item) => count + item.quantity, 0);
  }
}));
