import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { X, Plus, Minus, ShoppingCart, Clock, Leaf } from "lucide-react";
import { MenuItem, CartItem } from "@shared/schema";
import { useCartStore } from "@/lib/cart-store";
import { useToast } from "@/hooks/use-toast";

interface ItemDetailModalProps {
  item: MenuItem;
  isOpen: boolean;
  onClose: () => void;
}

export default function ItemDetailModal({ item, isOpen, onClose }: ItemDetailModalProps) {
  const [quantity, setQuantity] = useState(1);
  const addItem = useCartStore(state => state.addItem);
  const { toast } = useToast();

  const increaseQuantity = () => setQuantity(q => q + 1);
  const decreaseQuantity = () => setQuantity(q => Math.max(1, q - 1));

  const handleAddToCart = () => {
    const cartItem: CartItem = {
      ...item,
      quantity
    };
    
    addItem(cartItem);
    
    toast({
      title: "Added to cart",
      description: `${quantity}x ${item.name} added to your order`,
    });
    
    onClose();
    setQuantity(1);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl w-full max-h-[90vh] overflow-y-auto p-0 bg-white rounded-3xl">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-0">
          {/* Item Image */}
          <div className="relative">
            <img 
              src={item.image} 
              alt={item.name} 
              className="w-full h-88 object-cover rounded-l-3xl" 
            />
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              className="absolute top-4 right-4 bg-white bg-opacity-90 hover:bg-opacity-100 rounded-full p-2 transition-all"
            >
              <X className="h-4 w-4 text-dylan-black" />
            </Button>
          </div>
          
          {/* Item Details */}
          <div className="p-8">
            <h2 className="font-playfair text-3xl font-bold text-dylan-black mb-4">
              {item.name}
            </h2>
            <p className="text-dylan-brown mb-6 leading-relaxed">
              {item.description}
            </p>
            
            {/* Price and Add to Cart */}
            <div className="bg-dylan-beige/30 rounded-2xl p-6 mb-6 luxury-border">
              <div className="flex items-center justify-between mb-4">
                <span className="font-playfair text-2xl font-bold text-dylan-gold">
                  ${item.price.toFixed(2)}
                </span>
                <div className="flex items-center space-x-3">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={decreaseQuantity}
                    className="w-10 h-10 bg-dylan-gold hover:bg-dylan-gold/90 text-white rounded-full border-dylan-gold"
                  >
                    <Minus className="h-4 w-4" />
                  </Button>
                  <span className="text-xl font-semibold text-dylan-black w-8 text-center">
                    {quantity}
                  </span>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={increaseQuantity}
                    className="w-10 h-10 bg-dylan-gold hover:bg-dylan-gold/90 text-white rounded-full border-dylan-gold"
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              
              <Button
                onClick={handleAddToCart}
                className="w-full bg-dylan-gold hover:bg-dylan-gold/90 text-white font-semibold py-4 px-6 rounded-xl transition-all duration-200 transform hover:scale-105 luxury-shadow"
              >
                <ShoppingCart className="mr-2 h-5 w-5" />
                Add to Cart
              </Button>
            </div>
            
            {/* Additional Info */}
            <div className="space-y-3 text-sm text-dylan-brown">
              {item.preparationTime && (
                <div className="flex items-center">
                  <Clock className="mr-2 h-4 w-4 text-dylan-gold" />
                  <span>Preparation time: {item.preparationTime}</span>
                </div>
              )}
              <div className="flex items-center">
                <Leaf className="mr-2 h-4 w-4 text-dylan-gold" />
                <span>Made with premium ingredients</span>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
