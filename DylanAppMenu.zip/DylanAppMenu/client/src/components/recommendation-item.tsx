import { Button } from "@/components/ui/button";
import { MenuItem, CartItem } from "@shared/schema";
import { useCartStore } from "@/lib/cart-store";
import { useToast } from "@/hooks/use-toast";

interface RecommendationItemProps {
  item: MenuItem;
}

export default function RecommendationItem({ item }: RecommendationItemProps) {
  const addItem = useCartStore(state => state.addItem);
  const { toast } = useToast();

  const handleAdd = () => {
    const cartItem: CartItem = {
      ...item,
      quantity: 1
    };
    
    addItem(cartItem);
    
    toast({
      title: "Added to cart",
      description: `${item.name} added to your order`,
    });
  };

  return (
    <div className="flex items-center space-x-3 p-3 border luxury-border rounded-lg hover:bg-dylan-beige/20 transition-all cursor-pointer">
      <img 
        src={item.image} 
        alt={item.name} 
        className="w-12 h-12 object-cover rounded-lg" 
      />
      <div className="flex-1">
        <h4 className="font-semibold text-dylan-black text-sm">{item.name}</h4>
        <p className="text-xs text-dylan-brown line-clamp-1">
          Perfect pairing choice
        </p>
        <span className="text-dylan-gold font-semibold text-sm">
          ${item.price.toFixed(2)}
        </span>
      </div>
      <Button
        size="sm"
        onClick={handleAdd}
        className="bg-dylan-gold hover:bg-dylan-gold/90 text-white px-3 py-1 rounded-lg text-xs transition-all"
      >
        Add
      </Button>
    </div>
  );
}
