import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Plus } from "lucide-react";
import { MenuItem } from "@shared/schema";

interface MenuItemCardProps {
  item: MenuItem;
  onClick: () => void;
}

export default function MenuItemCard({ item, onClick }: MenuItemCardProps) {
  return (
    <Card 
      className="bg-white rounded-2xl luxury-shadow overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:scale-105 cursor-pointer luxury-border"
      onClick={onClick}
    >
      <img 
        src={item.image} 
        alt={item.name} 
        className="w-full h-48 object-cover" 
      />
      <CardContent className="p-6">
        <h3 className="font-playfair text-xl font-semibold text-dylan-black mb-2">
          {item.name}
        </h3>
        <p className="text-dylan-brown text-sm mb-3 line-clamp-2">
          {item.description}
        </p>
        <div className="flex items-center justify-between">
          <span className="font-semibold text-dylan-gold text-lg">
            ${item.price.toFixed(2)}
          </span>
          <Button 
            size="sm"
            className="bg-dylan-gold hover:bg-dylan-gold/90 text-white px-4 py-2 rounded-lg transition-all text-sm font-medium"
            onClick={(e) => {
              e.stopPropagation();
              onClick();
            }}
          >
            <Plus className="mr-1 h-4 w-4" />
            Add
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
