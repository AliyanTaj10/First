import { Button } from "@/components/ui/button";
import { Plus, Minus, Trash2 } from "lucide-react";
import { CartItem as CartItemType } from "@shared/schema";
import { useCartStore } from "@/lib/cart-store";

interface CartItemProps {
  item: CartItemType;
}

export default function CartItem({ item }: CartItemProps) {
  const { updateQuantity, removeItem } = useCartStore();

  const increaseQuantity = () => {
    updateQuantity(item.id, item.quantity + 1);
  };

  const decreaseQuantity = () => {
    if (item.quantity > 1) {
      updateQuantity(item.id, item.quantity - 1);
    }
  };

  const handleRemove = () => {
    removeItem(item.id);
  };

  const itemTotal = item.price * item.quantity;

  return (
    <div className="flex items-center space-x-4 p-4 border luxury-border rounded-xl bg-white">
      <img 
        src={item.image} 
        alt={item.name} 
        className="w-16 h-16 object-cover rounded-lg" 
      />
      <div className="flex-1">
        <h3 className="font-semibold text-dylan-black">{item.name}</h3>
        <p className="text-sm text-dylan-brown line-clamp-1">
          {item.description}
        </p>
        <span className="text-xs text-dylan-brown">
          ${item.price.toFixed(2)} each
        </span>
      </div>
      <div className="flex items-center space-x-2">
        <Button
          variant="outline"
          size="icon"
          onClick={decreaseQuantity}
          className="w-8 h-8 bg-dylan-gold/20 hover:bg-dylan-gold/30 text-dylan-gold rounded-full border-dylan-gold/30"
        >
          <Minus className="h-3 w-3" />
        </Button>
        <span className="text-lg font-semibold text-dylan-black w-8 text-center">
          {item.quantity}
        </span>
        <Button
          variant="outline"
          size="icon"
          onClick={increaseQuantity}
          className="w-8 h-8 bg-dylan-gold/20 hover:bg-dylan-gold/30 text-dylan-gold rounded-full border-dylan-gold/30"
        >
          <Plus className="h-3 w-3" />
        </Button>
      </div>
      <div className="text-right">
        <div className="font-semibold text-dylan-gold">
          ${itemTotal.toFixed(2)}
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={handleRemove}
          className="text-red-500 hover:text-red-700 transition-colors p-1"
        >
          <Trash2 className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
